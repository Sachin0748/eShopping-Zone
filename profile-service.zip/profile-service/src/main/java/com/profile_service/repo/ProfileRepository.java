package com.profile_service.repo;

import com.profile_service.entity.UserProfile;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfileRepository extends JpaRepository<UserProfile, Long> {

    UserProfile findByMobileNumber(Long mobileNumber);
    UserProfile findByFullName(String fullName);
}