package com.profile_service.entity;

public enum Role {
    CUSTOMER,
    MERCHANT,
    DELIVERY_AGENT
}