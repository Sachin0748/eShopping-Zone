package com.profile_service.entity;

import jakarta.persistence.MappedSuperclass;
import jakarta.validation.constraints.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
//import lombok.extern.slf4j.Slf4j;

@MappedSuperclass
@Data
@NoArgsConstructor
@AllArgsConstructor
//@Slf4j
public class Address {

    @Min(value = 1, message = "House number must be a positive integer")
    private int houseNumber;

    @NotBlank(message = "Street name cannot be blank")
    @Size(min = 2, max = 50, message = "Street name must be between 2 and 50 characters")
    private String streetName;

    @NotBlank(message = "Colony name cannot be blank")
    @Size(min = 2, max = 50, message = "Colony name must be between 2 and 50 characters")
    private String colonyName;

    @NotBlank(message = "City cannot be blank")
    @Size(min = 2, max = 50, message = "City name must be between 2 and 50 characters")
    private String city;

    @NotBlank(message = "State cannot be blank")
    @Size(min = 2, max = 50, message = "State name must be between 2 and 50 characters")
    private String state;

    @Min(value = 100000, message = "Pincode must be at least 6 digits")
    @Max(value = 999999, message = "Pincode must be a valid 6-digit number")
    private int pincode;

//    public void logAddressInfo() {
//        log.info("Address: {}, {}, {}, {}, {}, {}",
//                houseNumber, streetName, colonyName, city, state, pincode);
//    }
}
