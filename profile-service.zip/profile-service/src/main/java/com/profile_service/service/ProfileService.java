package com.profile_service.service;

import com.profile_service.entity.UserProfile;

import java.util.List;

public interface ProfileService {
    UserProfile addNewCustomerProfile(UserProfile userProfile);
    List<UserProfile> getAllProfiles();
    UserProfile getByProfileId(int profileId);
    void updateProfile(UserProfile userProfile);
    void deleteProfile(int profileId);
    void addNewMerchantProfile(UserProfile userProfile);
    void addNewDeliveryProfile(UserProfile userProfile);
    UserProfile findByMobileNumber(Long mobileNumber);
    UserProfile getByUserName(String fullName);
}