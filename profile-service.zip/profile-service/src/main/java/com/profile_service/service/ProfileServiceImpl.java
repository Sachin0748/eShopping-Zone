package com.profile_service.service;

import com.profile_service.entity.UserProfile;
import com.profile_service.repo.ProfileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProfileServiceImpl implements ProfileService {

    @Autowired
    private ProfileRepository profileRepository;

    @Override
    public UserProfile addNewCustomerProfile(UserProfile userProfile) {
        userProfile.setRole("Customer");
        return profileRepository.save(userProfile);
    }

    @Override
    public void addNewMerchantProfile(UserProfile userProfile) {
        userProfile.setRole("Merchant");
        profileRepository.save(userProfile);
    }

    @Override
    public void addNewDeliveryProfile(UserProfile userProfile) {
        userProfile.setRole("Delivery");
        profileRepository.save(userProfile);
    }

    @Override
    public List<UserProfile> getAllProfiles() {
        return profileRepository.findAll();
    }

    @Override
    public UserProfile getByProfileId(int profileId) {
        Optional<UserProfile> profile = profileRepository.findById((long) profileId);
        return profile.orElse(null); // Or throw custom exception
    }

    @Override
    public void updateProfile(UserProfile userProfile) {
        profileRepository.save(userProfile); // will update if ID exists
    }

    @Override
    public void deleteProfile(int profileId) {
        profileRepository.deleteById((long) profileId);
    }

    @Override
    public UserProfile findByMobileNumber(Long mobileNumber) {
        return profileRepository.findByMobileNumber(mobileNumber);
    }

    @Override
    public UserProfile getByUserName(String fullName) {
        return profileRepository.findByFullName(fullName);
    }
}
