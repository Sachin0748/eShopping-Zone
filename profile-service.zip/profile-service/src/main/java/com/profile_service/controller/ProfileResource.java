package com.profile_service.controller;

import com.profile_service.entity.UserProfile;
import com.profile_service.service.ProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/profile")
public class ProfileResource {

    @Autowired
    private ProfileService profileService;

    @PostMapping("/customer")
    public ResponseEntity<UserProfile> addNewCustomerProfile(@RequestBody UserProfile userProfile) {
        return ResponseEntity.ok(profileService.addNewCustomerProfile(userProfile));
    }

    @PostMapping("/merchant")
    public ResponseEntity<Void> addNewMerchantProfile(@RequestBody UserProfile userProfile) {
        profileService.addNewMerchantProfile(userProfile);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/delivery")
    public ResponseEntity<Void> addNewDeliveryProfile(@RequestBody UserProfile userProfile) {
        profileService.addNewDeliveryProfile(userProfile);
        return ResponseEntity.ok().build();
    }

    @GetMapping
    public ResponseEntity<List<UserProfile>> getAllProfiles() {
        return ResponseEntity.ok(profileService.getAllProfiles());
    }

    @GetMapping("/{profileId}")
    public ResponseEntity<UserProfile> getByProfileId(@PathVariable int profileId) {
        return ResponseEntity.ok(profileService.getByProfileId(profileId));
    }

    @GetMapping("/mobile/{mobileNumber}")
    public ResponseEntity<UserProfile> findByMobileNumber(@PathVariable Long mobileNumber) {
        return ResponseEntity.ok(profileService.findByMobileNumber(mobileNumber));
    }

    @GetMapping("/name/{fullName}")
    public ResponseEntity<UserProfile> getByUserName(@PathVariable String fullName) {
        return ResponseEntity.ok(profileService.getByUserName(fullName));
    }

    @PutMapping
    public ResponseEntity<Void> updateProfile(@RequestBody UserProfile userProfile) {
        profileService.updateProfile(userProfile);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{profileId}")
    public ResponseEntity<Void> deleteProfile(@PathVariable int profileId) {
        profileService.deleteProfile(profileId);
        return ResponseEntity.noContent().build();
    }
}